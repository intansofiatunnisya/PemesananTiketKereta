# Sistem Pemesanan Tiket Kereta Api

## Demo
![](assets/image/home.png)

## Login user
Hak akses level Admin/user
user
> username : user2

> password : admin

admin
> username : admin

> password : admin




## Feature
Feature simulasi pemesanan tiket kereta api sebagai berikut

User
* Dashboard
* Order
* Payment_Code

Admin
* Dashboard
* Create Schedule
* Edit Schedule
* Delete Schedule
* Validation Order
* Log Validation


## Authors.
0

* **Mochamad Yudi Sobari** - *Newbie Web Developers* - [VODONESIA](https://vodonesia.id)
Projek ini untuk memenuhi tugas Matakuliah Pemrograman Berbasis Website
